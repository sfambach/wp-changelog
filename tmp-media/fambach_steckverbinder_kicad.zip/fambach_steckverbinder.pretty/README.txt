fambach_steckverbinder.pretty - KiCad footprints for old PC power connectors
- TE_EI_171826-4_1x04_P2.50mm_Horizontal: own footprint (fambach.net), pads from TE customer drawing C-171826 Rev R4, body outline estimated. Verify before ordering PCBs.
- TE_MATE-N-LOK_350211-1_1x04_P5.08mm_Vertical, Joint-Tech_C5080WR-04P_1x04_P5.08mm_Vertical: copies from the official KiCad 7 library (CC-BY-SA 4.0 with exception, https://gitlab.com/kicad/libraries/kicad-footprints).
