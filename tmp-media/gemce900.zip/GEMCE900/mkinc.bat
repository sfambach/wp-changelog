
@rem ************************************************************************
@rem 
@rem Incremental build script for Gemulator / Xformer / SoftMac
@rem
@rem Requires Microsoft Visual Studio 98 / VC 6.0 or VC 7.x!!!
@rem For later versions of Visual Studio, import the ATARIST.SLN file first,
@rem then manually run MKALLASM.BAT before building the solution.
@rem
@rem ************************************************************************

del build\debug\atarist.exe
del build\ship\atarist.exe

@setlocal
pushd %VSCOMNTOOLS%
if exist webdbg.exe goto vc7

if "%%VSCOMNTOOLS%%"== "" goto vc6
if "%%VSCOMNTOOLS%%"== "%VSCOMNTOOLS%" goto vc6
if "%VSCOMNTOOLS%"  == "" goto vc6

pushd .

:vc7
popd
set CLT=%CL% -FAsc -MT -Gy -G6 -GF -Zi
set LINKT=%LINK%
set LINK=%LINK% /subsystem:windows,4.10
set LINK=%LINK% /version:9.00
set LINK=%LINK% /nodefaultlib:libc /defaultlib:libcmt
set LINK=%LINK% /entry:WinMainCRTStartup /fixed /largeaddressaware /opt:ref /release
set LINK=%LINK% /swaprun:cd /swaprun:net /ws:aggressive /opt:icf,999 /opt:nowin98

set CL=-GS %CLT%
if     "%1" == "debug" devenv atarist.sln /%REBUILD%build Debug
if     "%1" == "all"   devenv atarist.sln /%REBUILD%build Debug

set CL=-GA %CLT%
if     "%1" == "all"   devenv atarist.sln /%REBUILD%build Release
if     "%1" == "ship"  devenv atarist.sln /%REBUILD%build Release
if not "%1" == "debug" devenv atarist.sln /%REBUILD%build Release

goto done

:vc6

set CL=-GZ %CLT%
if     "%1" == "debug" msdev atarist.dsp /make "GEMUL8R - Win32 (80x86) Debug"
if     "%1" == "all"   msdev atarist.dsp /make "GEMUL8R - Win32 (80x86) Debug"

set CL=-GA %CLT%
if     "%1" == "all"   msdev atarist.dsp /make "GEMUL8R - Win32 (80x86) Release"
if     "%1" == "ship"  msdev atarist.dsp /make "GEMUL8R - Win32 (80x86) Release"
if not "%1" == "debug" msdev atarist.dsp /make "GEMUL8R - Win32 (80x86) Release"

:done
set CL=%CLT%
set LINK=%LINKT%
set REBUILD=
@endlocal

