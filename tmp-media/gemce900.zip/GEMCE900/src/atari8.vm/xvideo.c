
/***************************************************************************

    XVIDEO.C

    - Atari 8-bit video emulation

    Copyright (C) 1986-2008 by Darek Mihocka. All Rights Reserved.
    Branch Always Software. http://www.emulators.com/

    11/30/2008  darekm      open source release
    09/27/2000  darekm      last update

***************************************************************************/

#include "atari800.h"

#ifdef XFORMER

#define bfBK  0x00
#define bfPF0 0x01
#define bfPF1 0x02
#define bfPF2 0x04
#define bfPF3 0x08
#define bfPM0 0x10
#define bfPM1 0x20
#define bfPM2 0x40
#define bfPM3 0x80

//
// Scan line structure
//

#pragma pack(1)

typedef struct
{
    BYTE rgb[48];               // values of scanline data

    BYTE modehi;                // display list byte (hi nibble)
    BYTE modelo;                // display list byte (lo nibble)
    WORD addr;                  // starting address of scan line

    BYTE scan;                  // scan line within mode (0..15)
    BYTE dmactl;                // dmactl value
    BYTE chbase;                // starting page of text font
    BYTE chactl;                // character control

    union
        {
        struct
            {
            BYTE colpf0;
            BYTE colpf1;
            BYTE colpf2;
            BYTE colpf3;
            };
        ULONG colpfX;
        BYTE colpf[4];
        };

    BYTE hscrol:4;
    BYTE vscrol:4;
    BYTE prior;                 // priority / GTIA select
    BYTE colbk;

    BYTE fpmg;                  // PMG are present on scan line
} SL;

typedef struct
{
    union
        {
        struct
            {
            BYTE colpm0;
            BYTE colpm1;
            BYTE colpm2;
            BYTE colpm3;
            };
        ULONG colpmX;
        BYTE colpm[4];
        };

    union
        {
        struct
            {
            BYTE grafp0;
            BYTE grafp1;
            BYTE grafp2;
            BYTE grafp3;
            };
        ULONG grafpX;
        BYTE grafp[4];
        };

    union
        {
        struct
            {
            BYTE hposm0;
            BYTE hposm1;
            BYTE hposm2;
            BYTE hposm3;
            };
        ULONG hposmX;
        BYTE hposm[4];
        };

    union
        {
        struct
            {
            BYTE hposp0;
            BYTE hposp1;
            BYTE hposp2;
            BYTE hposp3;
            };
        ULONG hpospX;
        BYTE hposp[4];
        };

    union
        {
        struct
            {
            BYTE sizep0;
            BYTE sizep1;
            BYTE sizep2;
            BYTE sizep3;
            };
        ULONG sizepX;
        BYTE sizep[4];
        };

    BYTE grafm;
    BYTE sizem;
    BYTE pmbase;
} PMG;

#pragma pack()

// globals

SL rgsl[262];     // 256 scan line structures
PMG pmg;          // PMG structure (only 1 needed, updated each scan line)

BOOL fHitclr;

const WORD mpsizecw[4] = { 1, 2, 1, 4 };

const WORD mppmbw[5] =
    {
    (bfPM0 << 8) | bfPM0,
    (bfPM1 << 8) | bfPM1,
    (bfPM2 << 8) | bfPM2,
    (bfPM3 << 8) | bfPM3,
    (bfPF3 << 8) | bfPF3,
    };

BYTE const * const rgszModes[6] =
    {
    " ATARI 800 (NO CARTRIDGE)",
    " ATARI 800XL (NO CARTRIDGE)",
    " ATARI 130XE (NO CARTRIDGE)",
    " ATARI 800 + CARTRIDGE",
    " ATARI 800XL + CARTRIDGE",
    " ATARI 130XE + CARTRIDGE",
    };

#ifdef HWIN32
#define vcbScan vi.cbScan
#define wcScans 240
#else
#define vcbScan 320
#define wcScans 200
#endif

void ShowCountDownLine()
{
    WORD i = wScan - (wStartScan + wcScans - 8);

    // make sure bottom 8 scan lines

    if (i < 8)
        {
        BYTE *pch;
        int cch;
#ifdef HDOS16
        __segment videomem = 0xA000;
        BYTE __based(videomem) *qch = 0;
#else
#ifdef HDOS32
        BYTE *qch = 0xA0000;
#else
#ifdef HWIN32
        BYTE *qch = vi.pvBits;
#endif // HWIN32
#endif // HDOS32
#endif // HDOS16
        BYTE colfg;

        if (cntTick < 50)
            {
            pch = " XFORMER BY DAREK MIHOCKA";
            }
        else
            pch = (char *)rgszModes[mdXLXE + ((ramtop == 0xC000) ? 0 : 3)];
        qch += (wScan - wStartScan) * vcbScan;

        colfg = ((wFrame >> 2) << 4) + i + i;
        colfg = (((wFrame >> 2) + i) << 4) + 8;

        for (cch = 0; cch < 40; cch++)
            {
            BYTE b = *pch ? *pch - ' ' : 0;

            b = rgbAtariOSB[0x800 + (b << 3) + i];

            qch[0] = (b & 0x80) ? colfg : 0x00;
            qch[1] = (b & 0x40) ? colfg : 0x00;
            qch[2] = (b & 0x20) ? colfg : 0x00;
            qch[3] = (b & 0x10) ? colfg : 0x00;
            qch[4] = (b & 0x08) ? colfg : 0x00;
            qch[5] = (b & 0x04) ? colfg : 0x00;
            qch[6] = (b & 0x02) ? colfg : 0x00;
            qch[7] = (b & 0x01) ? colfg : 0x00;
            qch += 8;

            if (*pch)
                pch++;
            }

        if ((i == 7) && (cntTick == 1))
            {
            memset(rgsl,1,sizeof(rgsl));
            }

        if (i == 7)
            cntTick--;

#ifdef HWIN32
        if ((wScan >= wStartScan) && (wScan < (wStartScan+wcScans)))
            {
            vi.wScanMin = min(vi.wScanMin, (wScan - wStartScan));
            vi.wScanMac = max(vi.wScanMac, (wScan - wStartScan) + 1);
            }
#endif
        }
}

void DrawPlayers(WORD NEAR *pw)
{
    int i;
    int j;
    int cw;
    BYTE b2;
    WORD w;

    for (i = 0; i < 4; i++)
        {
        WORD NEAR *qw;
        
        if (!(b2 = pmg.grafp[i]))
            continue;

        qw = pw;
        qw += (pmg.hposp[i] - 48);

        cw = mpsizecw[ pmg.sizep[i] & 3];

        w  = mppmbw[i];

        for (j = 0; j < 8; j++)
            {
            if (b2 & 0x80)
                {
                qw[0] |= w;
                if (cw > 1)
                    {
                    qw[1] |= w;
                    if (cw > 2)
                        {
                        qw[2] |= w;
                        qw[3] |= w;
                        }
                    }
                }

            qw += cw;
            b2 <<= 1;
            }
        }

    // now do player-to-player and player-to-playfield collisions

    if (fHitclr)
        return;

    for (i = 0; i < 4; i++)
        {
        WORD NEAR *qw;
        
        if (!(b2 = pmg.grafp[i]))
            continue;

        qw = pw;
        qw += (pmg.hposp[i] - 48);

        cw = mpsizecw[ pmg.sizep[i] & 3];

        for (j = 0; j < 8; j++)
            {
            if (b2 & 0x80)
                {
                PXPL[i] |= (*qw >> 12);
                PXPF[i] |= *qw++;

                if (cw > 1)
                    {
                    PXPL[i] |= (*qw >> 12);
                    PXPF[i] |= *qw++;

                    if (cw > 2)
                        {
                        PXPL[i] |= (*qw >> 12);
                        PXPF[i] |= *qw++;
                        PXPL[i] |= (*qw >> 12);
                        PXPF[i] |= *qw++;
                        }
                    }
                }
            else
                qw += cw;

            b2 <<= 1;
            }

        // mask out upper 4 bits of each collision register
        // and mask out same player collisions

        *(ULONG *)PXPF &= 0x0F0F0F0F;
        *(ULONG *)PXPL &= 0x070B0D0E;
        }
}

#if _MSC_VER >= 1200
// VC 6.0 optimization bug having to do with (byte >> int)
#pragma optimize("",off)
#endif

void DrawMissiles(WORD NEAR *pw, int fFifth)
{
    int i;
    int cw;
    BYTE b2;
    WORD w;

    if (fHitclr)
        goto Ldm;

    // First do missile-to-player and missile-to-playfield collisions

    for (i = 0; i < 4; i++)
        {
        WORD NEAR *qw;
        
        if (!(b2 = ((pmg.grafm >> (i+i)) & 3)))
            continue;

        qw = (WORD NEAR *)pw;
        qw += (pmg.hposm[i] - 48);

        cw = mpsizecw[((pmg.sizem >> (i+i))) & 3];

        if (b2 & 2)
            {
            MXPL[i] |= (*qw >> 12);
            MXPF[i] |= *qw++;

            if (cw > 1)
                {
                MXPL[i] |= (*qw >> 12);
                MXPF[i] |= *qw++;

                if (cw > 2)
                    {
                    MXPL[i] |= (*qw >> 12);
                    MXPF[i] |= *qw++;
                    MXPL[i] |= (*qw >> 12);
                    MXPF[i] |= *qw++;
                    }
                }
            }
        else
            qw += cw;

        if (b2 & 1)
            {
            MXPL[i] |= (*qw >> 12);
            MXPF[i] |= *qw++;

            if (cw > 1)
                {
                MXPL[i] |= (*qw >> 12);
                MXPF[i] |= *qw++;

                if (cw > 2)
                    {
                    MXPL[i] |= (*qw >> 12);
                    MXPF[i] |= *qw++;
                    MXPL[i] |= (*qw >> 12);
                    MXPF[i] |= *qw;
                    }
                }
            }
        }

    // mask out upper 4 bits of each collision register

    *(ULONG *)MXPL &= 0x0F0F0F0F;
    *(ULONG *)MXPF &= 0x0F0F0F0F;

Ldm:
    for (i = 0; i < 4; i++)
        {
        WORD NEAR *qw;
        
        if (!(b2 = ((pmg.grafm >> (i+i)) & 3)))
            continue;

        qw = (WORD NEAR *)pw;
        qw += (pmg.hposm[i] - 48);

        cw = mpsizecw[((pmg.sizem >> (i+i))) & 3];

        if (fFifth)
            w  = mppmbw[4];
        else
            w  = mppmbw[i];

        if (b2 & 2)
            {
            if (0 && fFifth)
                {
                qw[0] |= w;
                if (cw > 1)
                    {
                    qw[1] |= w;
                    if (cw > 2)
                        {
                        qw[2] |= w;
                        qw[3] |= w;
                        }
                    }
                }
            else
                {
                qw[0] = w;
                if (cw > 1)
                    {
                    qw[1] = w;
                    if (cw > 2)
                        {
                        qw[2] = w;
                        qw[3] = w;
                        }
                    }
                }
            }
        qw += cw;

        if (b2 & 1)
            {
            if (0 && fFifth)
                {
                qw[0] |= w;
                if (cw > 1)
                    {
                    qw[1] |= w;
                    if (cw > 2)
                        {
                        qw[2] |= w;
                        qw[3] |= w;
                        }
                    }
                }
            else
                {
                qw[0] = w;
                if (cw > 1)
                    {
                    qw[1] = w;
                    if (cw > 2)
                        {
                        qw[2] = w;
                        qw[3] = w;
                        }
                    }
                }
            }
        }
}

#pragma optimize("",on)

__inline void IncDLPC()
{
    DLPC = (DLPC & 0xFC00) | ((DLPC+1) & 0x03FF);
}


#ifdef HWIN32
BOOL ProcessScanLine(BOOL fRender)
#else
void ProcessScanLine(BOOL fRender)
#endif
{
    static BYTE scan;
    static BYTE scans;
    static WORD addr;

    static BYTE fWait;        // wait until next VBI
    static BYTE fFetch;    // fetch next DL instruction
    static BYTE fDataChanged;

    static const WORD mpMdScans[16] =
        {
        1, 1, 8, 10, 8, 16, 8, 16, 8, 4, 4, 2, 1, 2, 1, 1
        };

    static const WORD mpMdBytes[16] =
        {
        0, 0, 32, 32, 32, 32, 16, 16, 8, 8, 16, 16, 16, 32, 32, 32
        };

    // table that says how many bits of data to shift for each
    // 2 clock horizontal delay

    static const WORD mpmdbits[16] =
        {
        0, 0, 4, 4, 4, 4, 2, 2,    1, 1, 2, 2, 2, 2, 2, 2
        };

    static SL sl;                // current scan line display info
    static SL *psl = &rgsl[0];

    static WORD cb, cbDisp;
    static WORD i, j;
    static WORD hshift;
    WORD rgfChanged = 0;
    BYTE rgpix[512];

    if (fRender)
        goto Lrender;

    psl = &rgsl[wScan];

    if (wScan == 8)
        {
        fWait = 0;
        fFetch = 1;
        }

    if (!fWait && fFetch && (DMACTL & 32))
        {
        static BYTE fVscrol = 0;

#ifndef NDEBUG
        extern BOOL  fDumpHW;

        if (fDumpHW)
            printf("Fetching DL byte at scan %d, DLPC=%04X, byte=%02X\n",
                 wScan, DLPC, cpuPeekB(DLPC));
#endif

        sl.modehi = cpuPeekB(DLPC);
        sl.modelo = sl.modehi & 0x0F;
        sl.modehi >>= 4;
        IncDLPC();

        if ((sl.modehi & 2) && !fVscrol && (sl.modelo >= 2))
            {
            fVscrol = TRUE;
            sl.vscrol = VSCROL & 15;
            scan = sl.vscrol;
            }
        else
            {
            scan = 0;
            sl.vscrol = 0;
            }

        switch (sl.modelo)
            {
        case 0:
            // display list blank line(s) instruction

            scans = (sl.modehi & 7);
            break;

        case 1:
            // display list jump instruction

            scans = 0;
            fWait = (sl.modehi & 4);

            {
            WORD w;

            w = cpuPeekB(DLPC);
            IncDLPC();
            w |= (cpuPeekB(DLPC) << 8);

            DLPC = w;
            }
            break;

        default:
            // normal display list entry

            scans = mpMdScans[sl.modelo]-1;

            if (sl.modehi & 4)
                {
                addr = cpuPeekB(DLPC);
                IncDLPC();
                addr |= (cpuPeekB(DLPC) << 8);
                IncDLPC();
                }
            break;
            }

        if (fVscrol && (!(sl.modehi & 2) || (sl.modelo < 2)))
            {
            fVscrol = FALSE;
            scans = VSCROL;
            }
        }

    // generate a DLI if necessary. Do so on the last scan of a mode

    if ((sl.modehi & 8) && (scan == scans) && (NMIEN & 0x80))
        {
        // DLI enabled, generate DLI

#ifndef NDEBUG
        extern BOOL  fDumpHW;

        if (fDumpHW)
            printf("DLI interrupt at scan %d\n", wScan);
#endif
        Interrupt();
          NMIST = 0x80 | 0x1F;
        regPC = cpuPeekW(0xFFFA);
        }

    // Check playfield width and set cb (number of bytes read by Antic)
    // and cbDisp (number of bytes actually displayed) appropriately

    switch (DMACTL & 3)
        {
    default:
        Assert(FALSE);
        break;

    case 0:
        sl.modelo = 0;
        cb = 0;
        cbDisp = cb;
        break;
    case 1:
        cb = mpMdBytes[sl.modelo];
        cbDisp = cb;
        if ((sl.modehi & 1) && (sl.modelo >= 2)) // hor. scrolling
            cb |= (cb >> 2);
        break;
    case 2:
        cb = mpMdBytes[sl.modelo];
        cbDisp = cb | (cb >> 2);
        if ((sl.modehi & 1) && (sl.modelo >= 2)) // hor. scrolling
            cb |= (cb >> 1);
        else
            cb |= (cb >> 2);
        break;
    case 3:
        cb = mpMdBytes[sl.modelo];
        cbDisp = cb | (cb >> 2);
        cb |= (cb >> 1);
        break;
        }

    if (scan == sl.vscrol)
        {
        sl.chbase = CHBASE & ((sl.modelo < 6) ? 0xFC : 0xFE);
        sl.chactl = CHACTL & 7;
        }

    // fill in current sl structure

    sl.scan   = scan;
    sl.addr   = addr;
    sl.dmactl = DMACTL;

    sl.prior  = PRIOR;

    if (((sl.modelo) >= 2) && (sl.modehi & 1))
        {
        sl.hscrol = HSCROL & 14;  // HACK: can't handle odd hscrol
        hshift = (sl.hscrol * mpmdbits[sl.modelo]) >> 1;
        }
    else
        {
        sl.hscrol = 0;
        hshift = 0;
        }

    pmg.hposmX = HPOSMX;
    pmg.hpospX = HPOSPX;
    pmg.sizem  = SIZEM;
    pmg.sizepX = SIZEPX;

    if (sl.dmactl & 0x10)
        pmg.pmbase = PMBASE & 0xF8;
    else
        pmg.pmbase = PMBASE & 0xFC;

    // If PM/G DMA is enabled, read player data

    if (sl.dmactl & 0x08 && GRACTL & 2)
        {
        if (sl.dmactl & 0x10)
            {
            pmg.grafp0 = cpuPeekB((pmg.pmbase << 8) + 1024 + wScan);
            pmg.grafp1 = cpuPeekB((pmg.pmbase << 8) + 1280 + wScan);
            pmg.grafp2 = cpuPeekB((pmg.pmbase << 8) + 1536 + wScan);
            pmg.grafp3 = cpuPeekB((pmg.pmbase << 8) + 1792 + wScan);
            }
        else
            {
            pmg.grafp0 = cpuPeekB((pmg.pmbase << 8) + 512 + (wScan>>1));
            pmg.grafp1 = cpuPeekB((pmg.pmbase << 8) + 640 + (wScan>>1));
            pmg.grafp2 = cpuPeekB((pmg.pmbase << 8) + 768 + (wScan>>1));
            pmg.grafp3 = cpuPeekB((pmg.pmbase << 8) + 896 + (wScan>>1));
            }
        GRAFPX = pmg.grafpX;
        }
    else
        {
        pmg.grafpX = GRAFPX;
#if 0
        pmg.pmbase = 0;
#endif
        }

    if (sl.dmactl & 0x04 && GRACTL & 1)
        {
        if (sl.dmactl & 0x10)
            pmg.grafm = cpuPeekB((pmg.pmbase << 8) + 768 + wScan);
        else
            pmg.grafm = cpuPeekB((pmg.pmbase << 8) + 384 + (wScan>>1));

        GRAFM = pmg.grafm;
        }
    else
        pmg.grafm = GRAFM;

    if (pmg.grafpX)
        {
        // Players that are offscreen are treated as invisible

        if ((pmg.hposp0 < 32) || (pmg.hposp0 >= 216))
            pmg.grafp0 = 0;
        if ((pmg.hposp1 < 32) || (pmg.hposp1 >= 216))
            pmg.grafp1 = 0;
        if ((pmg.hposp2 < 32) || (pmg.hposp2 >= 216))
            pmg.grafp2 = 0;
        if ((pmg.hposp3 < 32) || (pmg.hposp3 >= 216))
            pmg.grafp3 = 0;
        }

    if (pmg.grafm)
        {
        // Missiles that are offsecreen are treated as invisible

        if ((pmg.hposm0 < 32) || (pmg.hposm0 >= 216))
            pmg.grafm &= ~0x03;
        if ((pmg.hposm1 < 32) || (pmg.hposm1 >= 216))
            pmg.grafm &= ~0x0C;
        if ((pmg.hposm2 < 32) || (pmg.hposm2 >= 216))
            pmg.grafm &= ~0x30;
        if ((pmg.hposm3 < 32) || (pmg.hposm3 >= 216))
            pmg.grafm &= ~0xC0;
        }

    // set PM/G flag if any player or missile data is non-zero

    sl.fpmg = (pmg.grafpX || pmg.grafm);

    // If GTIA is enabled, only let mode 15 display GTIA, all others blank

    if (sl.prior & 0xC0)
        {
        if (sl.modelo >= 15)
            {
            sl.modelo = 15 + (sl.prior >> 6);
            }
        else
            {
            sl.modelo = 0;
            cb = 0;
            }
        }

#ifdef HWIN32
    return 0;
#else
    return;
#endif

Lrender:

    sl.colbk  = COLBK;
    sl.colpfX = COLPFX;
    pmg.colpmX = COLPMX;

#if 0
#ifdef HDOS16ORDOS32
    if ((wScan < (wStartScan-scans)) || (wScan >= (wStartScan+wcScans)))
        goto Lnextscan;
#endif
#endif

#ifdef HDOS16ORDOS32
    if ((wScan < 16) || (wScan >= 240))
#else
    if ((wScan < 8) || (wScan >= 248))
#endif
        goto Lnextscan;

    rgfChanged = 0;

#define fModelo       1
#define fModehi       2
#define fScan       4
#define fAddr       8
#define fDmactl       16
#define fChbase       32
#define fChactl       64
#define fColbk       128
#define fColpf0       256
#define fColpf1       512
#define fColpf2       1024
#define fColpf3       2048
#define fColpfX       (fColpf0|fColpf1|fColpf2|fColpf3)
#define fPrior      4096
#define fFineScroll 8192
#define fPMG        16384
#define fDisp       0x8000
#define fAll        0xFFFF

    if (sl.modelo != psl->modelo) rgfChanged |= fModelo;
    if (sl.modehi != psl->modehi) rgfChanged |= fModehi;
    if (sl.scan   != psl->scan  ) rgfChanged |= fScan;    
    if (sl.addr   != psl->addr  ) rgfChanged |= fAddr;    
    if (sl.dmactl != psl->dmactl) rgfChanged |= fDmactl;
    if (sl.chbase != psl->chbase) rgfChanged |= fChbase;
    if (sl.chactl != psl->chactl) rgfChanged |= fChactl;
    if (sl.colbk  != psl->colbk ) rgfChanged |= fColbk;    
#if 1
    if (sl.colpfX != psl->colpfX) rgfChanged |= fColpfX;
#else
    if (sl.colpf0 != psl->colpf0) rgfChanged |= fColpf0;
    if (sl.colpf1 != psl->colpf1) rgfChanged |= fColpf1;
    if (sl.colpf2 != psl->colpf2) rgfChanged |= fColpf2;
    if (sl.colpf3 != psl->colpf3) rgfChanged |= fColpf3;
#endif
    if (sl.prior  != psl->prior)  rgfChanged |= fPrior;
    if (sl.vscrol != psl->vscrol) rgfChanged |= fFineScroll;
    if (sl.hscrol != psl->hscrol) rgfChanged |= fFineScroll;

    if (sl.fpmg   |  psl->fpmg)   rgfChanged |= fPMG;

#if 0
    if (rgfChanged & fPMG)
              {
        rgfChanged |= fAll;
        }
#endif

    // Even if rgfChanged is 0 at this point, we have to check the 10 to 48
    // data bytes associated with this scan line. If it is the first scan line
    // of this mode then we need to blit and compare the memory.
    // If it isn't the first scan line and !fDataChanged then there is no
    // need to blit and compare since nothing changed since the first scan line.

    if (((sl.modelo) >= 2) && (rgfChanged || (scan == sl.vscrol) || (fDataChanged)))
        {
        WORD j = 0;

        // if wide playfield, offset cbDisp/10 bytes into the scan line

        if (cbDisp != cb)
            {
            j = (cbDisp>>3) - (cbDisp>>5) - ((hshift+7) >> 3);
            hshift &= 7;
            }

        if (fDataChanged)
            {
            // sl.rgb already has data from previous scan line
            }
        else if (((addr+j) & 0xFFF) < 0xFD0)
            _fmemcpy(sl.rgb,&rgbMem[addr+j],cb);
        else
            {
            for (i = 0; i < cb; i++)
                sl.rgb[i] = cpuPeekB((addr & 0xF000) | ((addr+i+j) & 0x0FFF));
            }
    
        if (fDataChanged || memcmp(&sl.rgb, &psl->rgb[0], cb))
            {
            rgfChanged |= fDisp;
            fDataChanged = 1;
            }
        }

    // check if scan line is visible and if so redraw it

    if (rgfChanged && (wScan >= wStartScan) && (wScan < (wStartScan+wcScans)))
        {
        // redraw scan line

#ifdef HDOS16
        __segment videomem = 0xA000;
        BYTE __based(videomem) *qch0 = 0;
#else
#ifdef HDOS32
        BYTE *qch0 = 0xA0000;
#else
#ifdef HWIN32
        BYTE *qch0 = vi.pvBits;
#endif // HWIN32
#endif // HDOS32
#endif // HDOS16

        BYTE FAR *qch = qch0;

        BYTE b1, b2;
        BYTE col0, col1, col2, col3;
        BYTE vpix = scan;

#ifndef NDEBUG
        // show current stack

        qch[regSP & 0xFF] = (BYTE)(cpuPeekB(regSP | 0x100) ^ wFrame);
#endif

#ifdef HWIN32
        if ((wScan >= wStartScan) && (wScan < (wStartScan+wcScans)))
            {
            vi.wScanMin = min(vi.wScanMin, (wScan - wStartScan));
            vi.wScanMac = max(vi.wScanMac, (wScan - wStartScan) + 1);
            }
#endif

        if (sl.fpmg)
            {
            // When PM/G are present on the scan line is first rendered
            // into rgpix as bytes of bit vectors representing the playfields
            // and PM/G that are present at each pixel. Then later we map
            // rgpix to actual colors on the screen, applying priorities
            // in the process.

            qch = &rgpix[96];
            _fmemset(&rgpix[64], 0, 32);
            _fmemset(&rgpix[416], 0, 32);
            _fmemset(rgpix, 0, sizeof(rgpix));

            sl.colbk  = bfBK;
            sl.colpf0 = bfPF0;
            sl.colpf1 = bfPF1;
            sl.colpf2 = bfPF2;
            sl.colpf3 = bfPF3;
            }
        else
            qch += (wScan - wStartScan) * vcbScan;

        if ((sl.modelo >= 2) && ((sl.dmactl & 3) == 1))
            {
            if (rgfChanged & (fPMG|fDmactl|fModelo|fColbk))
                {
                memset(qch,sl.colbk,32);
                memset(qch+288,sl.colbk,32);
                }
            qch += 32;
            }

        rgfChanged &= ~fDisp;

        if (hshift)
            rgfChanged |= fFineScroll;

        switch (sl.modelo)
            {
        default:
            if (!(rgfChanged & (fPMG | fDmactl | fModelo | fColbk)))
                break;

            // just draw a blank scan line

            _fmemset(qch, sl.colbk, 320);
            break;

        case 2:
            col1 = (sl.colpf2 & 0xF0) | (sl.colpf1 & 0x0F);
            col2 = sl.colpf2;

            if (sl.chactl & 4)
                vpix = vpix ^ 7;    // vertical reflect bit
            vpix &= 7;

            for (i = 0 ; i < cbDisp; i++, qch += 8)
                {
                BYTE rgch[8];

                if (((b1 = sl.rgb[i]) == psl->rgb[i]) && !rgfChanged)
                    continue;

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u;

                    u = (cpuPeekB((sl.chbase<<8) + ((b1&0x7F)<<3) + vpix) << 8) |
                         cpuPeekB((sl.chbase<<8) + (sl.rgb[i+1]<<3) + vpix);

                         // BUG: not checking inverse bit of sl.rgb[i+1]

                    b2 = (BYTE)(u >> hshift);
                    }
                else
                    b2 = cpuPeekB((sl.chbase<<8) + ((b1&0x7F)<<3) + vpix);

                if (b1 & 0x80)
                    {
                    if (sl.chactl & 1)  // blank (blink) flag
                        b2 = 0;

                    if (sl.chactl & 2)  // inverse flag
                        b2 = ~b2;
                    }

//    col2 ^= cpuPeekB(20);


                if (b2 == 0)
                    {
                    memset(qch,col2,8);
                    continue;
                    }

                if (b2 == 255)
                    {
                    memset(qch,col1,8);
                    continue;
                    }

                memset(rgch,col2,8);

#ifndef ASM
                if (b2 & 0x80)
                    rgch[0] = col1;

                if (b2 & 0x40)
                    rgch[1] = col1;

                if (b2 & 0x20)
                    rgch[2] = col1;

                if (b2 & 0x10)
                    rgch[3] = col1;

                if (b2 & 0x08)
                    rgch[4] = col1;

                if (b2 & 0x04)
                    rgch[5] = col1;

                if (b2 & 0x02)
                    rgch[6] = col1;

                if (b2 & 0x01)
                    rgch[7] = col1;
#else // ASM
                _asm {
                    mov   al,b2
                    mov   ah,col1

                    test  al,128
                    je    short l280
                    mov   [rgch],ah
l280:
                    test  al,64
                    je    short l240
                    mov   [rgch+1],ah
l240:
                    test  al,32
                    je    short l220
                    mov   [rgch+2],ah
l220:
                    test  al,16
                    je    short l210
                    mov   [rgch+3],ah
l210:
                    test  al,8
                    je    short l208
                    mov   [rgch+4],ah
l208:
                    test  al,4
                    je    short l204
                    mov   [rgch+5],ah
l204:
                    test  al,2
                    je    short l202
                    mov   [rgch+6],ah
l202:
                    test  al,1
                    je    short l201
                    mov   [rgch+7],ah
l201:
                    }
#endif // ASM

                _fmemcpy(qch,rgch,8);
                }
            break;

        case 3:
            if (sl.chactl & 4)
                vpix = 9 - vpix;    // vertical reflect bit
            vpix %= 10;

            for (i = 0 ; i < cbDisp; i++)
                {
                if (((b1 = sl.rgb[i]) != psl->rgb[i]) || rgfChanged)
                    {
                    if (b1 & 0x80)
                        {
                        if (sl.chactl & 2)  // inverse flag
                            col2 = (sl.colpf2 & 0xF0) | (sl.colpf1 & 0x0F);
                        else
                            col2 = sl.colpf2;

                        if (sl.chactl & 1)  // blank (blink) flag
                            col2 = sl.colpf2;

                        col1 = sl.colpf2;
                        b1 &= 0x7F;
                        }
                    else
                        {
                        col1 = (sl.colpf2 & 0xF0) | (sl.colpf1 & 0x0F);
                        col2 = sl.colpf2;
                        }

                    if (hshift)
                        {
                        // non-zero horizontal scroll

                        WORD u;

                        u = (cpuPeekB((sl.chbase<<8) + (b1<<3) + vpix) << 8) |
                             cpuPeekB((sl.chbase<<8) + (sl.rgb[i+1]<<3) + vpix);

                         // BUG: not checking inverse bit of sl.rgb[i+1]
                         // BUG: not checking alignment

                        b2 = (BYTE)(u >> hshift);
                        }
                    else if ((vpix >= 2) && (vpix < 8))
                        b2 = cpuPeekB(((sl.chbase & 0xFC) << 8) + (b1 << 3) + vpix);
                    else if ((vpix < 2) && (b1 < 0x60))
                        b2 = cpuPeekB(((sl.chbase & 0xFC) << 8) + (b1 << 3) + vpix);
                    else if ((vpix >= 8) && (b1 >= 0x60))
                        b2 = cpuPeekB(((sl.chbase & 0xFC) << 8) + (b1 << 3) + vpix - 8);
                    else
                        b2 = 0;

                    for (j = 0; j < 8; j++)
                        {
                        if (b2 & 0x80)
                            *qch++ = col1;
                        else
                            *qch++ = col2;
                        b2 <<= 1;
                        }
                    }
                else
                    {
                    qch += 8;
                    }
                }
            break;

        case 5:
            vpix = scan >> 1;
        case 4:
            if (sl.chactl & 4)
                vpix ^= 7;                // vertical reflect bit
            vpix &= 7;

            col0 = sl.colbk;
            col1 = sl.colpf0;
            col2 = sl.colpf1;
//            col3 = sl.colpf2;

            for (i = 0 ; i < cbDisp; i++)
                {
                if (((b1 = sl.rgb[i]) == psl->rgb[i]) && !rgfChanged)
                    {
                    qch += 8;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u;

                    u = (cpuPeekB((sl.chbase<<8) + ((b1 & 0x7F)<<3) + vpix) << 8) |
                         cpuPeekB((sl.chbase<<8) + ((sl.rgb[i+1] & 0x7F)<<3) + vpix);

                    b2 = (BYTE)(u >> hshift);
                    }
                else
                    b2 = cpuPeekB((sl.chbase<<8) + ((b1 & 0x7F)<<3) + vpix);

                if (b1 & 0x80)
                    col3 = sl.colpf3;
                else
                    col3 = sl.colpf2;

                for (j = 0; j < 4; j++)
                    {
                    switch (b2 & 0xC0)
                        {
                    default:
                        Assert(FALSE);
                        break;
                
                    case 0x00:
                        *qch++ = col0;
                        *qch++ = col0;
                        break;

                    case 0x40:
                        *qch++ = col1;
                        *qch++ = col1;
                        break;

                    case 0x80:
                        *qch++ = col2;
                        *qch++ = col2;
                        break;

                    case 0xC0:
                        *qch++ = col3;
                        *qch++ = col3;
                        break;
                        }
                    b2 <<= 2;
                    }
                }
            break;

        case 7:
            vpix = scan >> 1;
        case 6:
            if (sl.chactl & 4)
                vpix ^= 7;                // vertical reflect bit
            vpix &= 7;

            col0 = sl.colbk;

            for (i = 0 ; i < cbDisp; i++)
                {
                if (((b1 = sl.rgb[i]) != psl->rgb[i]) || rgfChanged)
                    {
                    col1 = sl.colpf[b1>>6];

                    if (hshift)
                        {
                        // non-zero horizontal scroll

                        WORD u;

                        u = (cpuPeekB((sl.chbase<<8) + ((b1 & 0x3F)<<3) + vpix) << 8) |
                             cpuPeekB((sl.chbase<<8) + ((sl.rgb[i+1] & 0x3F)<<3) + vpix);

                        b2 = (BYTE)(u >> hshift);
                        
                        for (j = 0; j < 8; j++)
                            {
                            if (j == hshift)
                                col1 = sl.colpf[sl.rgb[i+1]>>6];

                            if (b2 & 0x80)
                                {
                                *qch++ = col1;
                                *qch++ = col1;
                                }
                            else
                                {
                                *qch++ = col0;
                                *qch++ = col0;
                                }
                            b2 <<= 1;
                            }
                        }
                    else
                        {
                        b2 = cpuPeekB((sl.chbase << 8)
                            + ((b1 & 0x3F) << 3) + vpix);

                        for (j = 0; j < 8; j++)
                            {
                            if (b2 & 0x80)
                                {
                                *qch++ = col1;
                                *qch++ = col1;
                                }
                            else
                                {
                                *qch++ = col0;
                                *qch++ = col0;
                                }
                            b2 <<= 1;
                            }
                        }
                    }
                else
                    {
                    qch += 16;
                    }
                }
            break;

        case 8:
            col0 = sl.colbk;
            col1 = sl.colpf0;
            col2 = sl.colpf1;
            col3 = sl.colpf2;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 32;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                for (j = 0; j < 4; j++)
                    {
                    switch (b2 & 0xC0)
                        {
                    default:
                        Assert(FALSE);
                        break;
                
                    case 0x00:
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        break;

                    case 0x40:
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        break;

                    case 0x80:
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        break;

                    case 0xC0:
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        break;
                        }
                    b2 <<= 2;
                    }
                }
            break;

        case 9:
            col0 = sl.colbk;
            col1 = sl.colpf0;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 32;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                for (j = 0; j < 8; j++)
                    {
                    if (b2 & 0x80)
                        {
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        }
                    else
                        {
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        }
                    b2 <<= 1;
                    }
                }
            break;

        case 10:
            col0 = sl.colbk;
            col1 = sl.colpf0;
            col2 = sl.colpf1;
            col3 = sl.colpf2;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 16;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                for (j = 0; j < 4; j++)
                    {
                    switch (b2 & 0xC0)
                        {
                    default:
                        Assert(FALSE);
                        break;
                
                    case 0x00:
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        *qch++ = col0;
                        break;

                    case 0x40:
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        *qch++ = col1;
                        break;

                    case 0x80:
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        *qch++ = col2;
                        break;

                    case 0xC0:
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        *qch++ = col3;
                        break;
                        }
                    b2 <<= 2;
                    }
                }
            break;

        case 11:
        case 12:
            col0 = sl.colbk;
            col1 = sl.colpf0;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 16;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                for (j = 0; j < 8; j++)
                    {
                    if (b2 & 0x80)
                        {
                        *qch++ = col1;
                        *qch++ = col1;
                        }
                    else
                        {
                        *qch++ = col0;
                        *qch++ = col0;
                        }
                    b2 <<= 1;
                    }
                }
            break;

        case 13:
        case 14:
            col0 = sl.colbk;
            col1 = sl.colpf0;
            col2 = sl.colpf1;
            col3 = sl.colpf2;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 8;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                for (j = 0; j < 4; j++)
                    {
                    switch (b2 & 0xC0)
                        {
                    default:
                        Assert(FALSE);
                        break;
                
                    case 0x00:
                        *qch++ = col0;
                        *qch++ = col0;
                        break;

                    case 0x40:
                        *qch++ = col1;
                        *qch++ = col1;
                        break;

                    case 0x80:
                        *qch++ = col2;
                        *qch++ = col2;
                        break;

                    case 0xC0:
                        *qch++ = col3;
                        *qch++ = col3;
                        break;
                        }
                    b2 <<= 2;
                    }
                }
            break;

        case 15:
            col1 = (sl.colpf2 & 0xF0) | (sl.colpf1 & 0x0F);
            col2 = sl.colpf2;

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 8;
                    continue;
                    }

                if (hshift)
                    {
                    // non-zero horizontal scroll

                    WORD u = (b2 << 8) | sl.rgb[i+1];
                    b2 = (BYTE)(u >> hshift);
                    }

                if (b2 == 0)
                    {
                    memset(qch,col2,8);
                    qch += 8;
                    continue;
                    }

                if (b2 == 255)
                    {
                    memset(qch,col1,8);
                    qch += 8;
                    continue;
                    }

                for (j = 0; j < 8; j++)
                    {
                    if (b2 & 0x80)
                        *qch++ = col1;
                    else
                        *qch++ = col2;
                    b2 <<= 1;
                    }
                }
            break;

        case 16:
            // GTIA 16 grey mode

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 8;
                    continue;
                    }

                col1 = (b2 >> 4) | ((sl.colbk & 15) << 4);
                col2 = (b2 & 15) | ((sl.colbk & 15) << 4);

                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;

                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                }
            break;

        case 17:
            // GTIA 9 color mode

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 8;
                    continue;
                    }

                col1 = (b2 >> 4);

                if (col1 < 9)
                    {
                    col1 = *(((BYTE FAR *)&COLPM0) + col1);
                    }
                else
                    col1 = 0;

                col2 = (b2 & 15);

                if (col2 < 9)
                    {
                    col2 = *(((BYTE FAR *)&COLPM0) + col2);
                    }
                else
                    col2 = 0;

                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;

                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                }
            break;

        case 18:
            // GTIA 16 color mode

            for (i = 0 ; i < cbDisp; i++)
                {
                b2 = sl.rgb[i];

                if (!rgfChanged && (b2 == psl->rgb[i]))
                    {
                    qch += 8;
                    continue;
                    }

                col1 = ((b2 >> 4) << 4) | (sl.colbk & 15);
                col2 = ((b2 & 15) << 4) | (sl.colbk & 15);

                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;
                *qch++ = col1;

                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                *qch++ = col2;
                }
            break;

            }
        }

    sl.colbk  = COLBK;
    sl.colpfX = COLPFX;

    if (rgfChanged || fDataChanged)
        *psl = sl;

    if ((wScan < wStartScan) || (wScan >= (wStartScan+wcScans)))
        goto Lnextscan;

    if (sl.fpmg)
        {
#ifdef HDOS16
        __segment videomem = 0xA000;
        BYTE __based(videomem) *qch = 0;
#else
#ifdef HDOS32
        BYTE *qch = 0xA0000;
#else
#ifdef HWIN32
        BYTE *qch = vi.pvBits;
#endif // HWIN32
#endif // HDOS32
#endif // HDOS16

        // now set the bits in rgpix corresponding to players and missiles

        DrawPlayers((WORD NEAR *)(rgpix+96));
        DrawMissiles((WORD NEAR *)(rgpix+96), sl.prior & 16);

#ifndef NDEBUG
    if (0)
        if (*(ULONG *)MXPF || *(ULONG *)MXPL || *(ULONG *)PXPF || *(ULONG *)PXPL)
            {
            DebugStr("wScan = %03d, MXPF:%08X MXPL:%08X PXPF:%08X PXPL:%08X, %03d %03d %03d %03d, %d\n", wScan,
                *(ULONG *)MXPF, *(ULONG *)MXPL, *(ULONG *)PXPF, *(ULONG *)PXPL,
                pmg.hposp0, pmg.hposp1, pmg.hposp2, pmg.hposp3, VDELAY);
            }
#endif

        fHitclr = 0;

        // if in a 2 color mode, set playfield 1 color

        if ((sl.modelo == 2) || (sl.modelo == 3) || (sl.modelo == 15))
            sl.colpf1 = (sl.colpf2 & 0xF0) | (sl.colpf1 & 0x0F);

        if ((wScan < wStartScan) || (wScan >= (wStartScan+wcScans)))
            goto Lnextscan;

        // now map the rgpix array to the screen

        qch += (wScan - wStartScan) * vcbScan;

        // if GTIA, give players and missiles highest priority

        if (sl.modelo > 15)
            sl.prior = 1;

        for (i = 0; i < 320; i++)
            {
            BYTE b = rgpix[i+96];

#if 1
            if (b == 0)
                {
                // just background

                if (sl.modelo <= 15)
                    b = sl.colbk;
                }
            else if ((b & 0xF0) == 0)
                {
                // just playfield, no missiles

                if (sl.modelo > 15)
                    ;
                else if (b & bfPF0)
                    b = sl.colpf0;
                else if (b & bfPF1)
                    b = sl.colpf1;
                else if (b & bfPF2)
                    b = sl.colpf2;
                else
                    b = sl.colpf3;
                }
            else
                {
                switch (sl.prior & 15)
                    {
                case 0:
                case 1:   // P0 P1 P2 P3 PF0 PF1 PF2 PF3
LdrawPM01:
                    if ((sl.prior & 32) &&
                           ((b & (bfPM0|bfPM1)) == (bfPM0|bfPM1)))
                        b = pmg.colpm0 | pmg.colpm1;
                    else if (b & bfPM0)
                        b = pmg.colpm0;
                    else if (b & bfPM1)
                        b = pmg.colpm1;
                    else
                        {
LdrawPM23:
                        if ((sl.prior & 32) &&
                               ((b & (bfPM2|bfPM3)) == (bfPM2|bfPM3)))
                            b = pmg.colpm2 | pmg.colpm3;
                        else if (b & bfPM2)
                            b = pmg.colpm2;
                        else if (b & bfPM3)
                            b = pmg.colpm3;
                        }
                    break;

                case 2:
                    if ((sl.prior & 32) &&
                           ((b & (bfPM0|bfPM1)) == (bfPM0|bfPM1)))
                        b = pmg.colpm0 | pmg.colpm1;
                    else if (b & bfPM0)
                        b = pmg.colpm0;
                    else if (b & bfPM1)
                        b = pmg.colpm1;
                    else if (b & bfPF0)
                        b = sl.colpf0;
                    else if (b & bfPF1)
                        b = sl.colpf1;
                    else if (b & bfPF2)
                        b = sl.colpf2;
                    else if (b & bfPF3)
                        b = sl.colpf3;
                    else
                        goto LdrawPM23;
                    break;

                case 3:
                case 4:
                    if (b & bfPF0)
                        b = sl.colpf0;
                    else if (b & bfPF1)
                        b = sl.colpf1;
                    else if (b & bfPF2)
                        b = sl.colpf2;
                    else if (b & bfPF3)
                        b = sl.colpf3;
                    else
                        goto LdrawPM01;
                    break;

                default:
                case 8:
                    if (b & bfPF0)
                        b = sl.colpf0;
                    else if (b & bfPF1)
                        b = sl.colpf1;
                    else if ((sl.prior & 32) &&
                           ((b & (bfPM0|bfPM1)) == (bfPM0|bfPM1)))
                        b = pmg.colpm0 | pmg.colpm1;
                    else if (b & bfPM0)
                        b = pmg.colpm0;
                    else if (b & bfPM1)
                        b = pmg.colpm1;
                    else if ((sl.prior & 32) &&
                           ((b & (bfPM2|bfPM3)) == (bfPM2|bfPM3)))
                        b = pmg.colpm2 | pmg.colpm3;
                    else if (b & bfPM2)
                        b = pmg.colpm2;
                    else if (b & bfPM3)
                        b = pmg.colpm3;
                    else if (b & bfPF2)
                        b = sl.colpf2;
                    else if (b & bfPF3)
                        b = sl.colpf3;
                    break;
                    }
                }
#endif

            qch[i] = b;
            }
        }

    // Check if mode status countdown is in effect

//    printf("cntTick = %d\n", cntTick);

    if (cntTick)
        {
        ShowCountDownLine();
        }

#ifndef NDEBUG

    // display the collision registers on each scan line
    //
    // collision registers consist of 8 bytes starting 
    // $D000 in the GTIA chip

    {
#ifdef HDOS16
    __segment videomem = 0xA000;
    BYTE __based(videomem) *qch = 0;
#else
#ifdef HDOS32
    BYTE *qch = 0xA0000;
#else
#ifdef HWIN32
    BYTE *qch = vi.pvBits;
#endif // HWIN32
#endif // HDOS32
#endif // HDOS16

    int i;

    qch += (wScan - wStartScan) * vcbScan + vcbScan - 81;

    if (wScan == 128)
        {
        qch[-8] = 0xFF;
        qch[-7] = 0xFF;
        qch[-6] = 0xFF;
        qch[-5] = 0xFF;
        qch[-4] = 0xFF;
        }

    qch[-7] = 0;
    qch[-6] = COLBK;
    qch[-5] = COLPF0;
    qch[-4] = COLPF1;
    qch[-3] = COLPF2;
    qch[-2] = COLPF3;
    qch[-1] = 0;

    if (fHitclr)
        {
        fHitclr = 0;

        qch[-3] = 0x48;
        qch[-2] = 0x48;
        qch[-1] = 0x48;
        }

    for (i = 0; i < 16; i++)
        {
        int j, k;

        *qch++ = 0x48;

        k = cpuPeekB(readGTIA+i);

        for (j = 0; j < 4; j++)
            {
            *qch++ = (k & 8) ? 0xFF : ((i & ~3)<<4)+2;
            k <<= 1;
            }
        }

    *qch++ = 0x48;
    }
#endif // NDEBUG

Lnextscan:
    // move on to the next scan line

    fFetch = (scan == scans);
    scan = (scan + 1) & 15;

    if (fFetch)
        {
        addr = (addr & 0xF000) | ((addr+cb) & 0x0FFF);
        fDataChanged = 0;
        }

#ifdef HWIN32
    return rgfChanged;
#endif
}

void ForceRedraw()
{
    memset(rgsl,0,sizeof(rgsl));
}

#endif // XFORMER

