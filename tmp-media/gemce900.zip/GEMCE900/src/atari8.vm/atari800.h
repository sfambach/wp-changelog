
/***************************************************************************

    ATARI800.H

    - Common include file for all Atari 800 VM components.
    - Defines all of the private variables used by the Atari 800 VM.

    Copyright (C) 1986-2008 by Darek Mihocka. All Rights Reserved.
    Branch Always Software. http://www.emulators.com/

    11/30/2008  darekm      open source release
    12/07/1998  darekm      PC Xformer 3.8 release

***************************************************************************/

#include "common.h"
#include "6502.h"

//
// Build flags
//
// XE is non-zero when 130XE emulation is wanted
//

#define XE 1


//
// Shift key status bits (are returned by PC BIOS)
//

#define wCapsLock 0x40
#define wNumLock  0x20
#define wScrlLock 0x10
#define wAlt      0x08
#define wCtrl     0x04
#define wAnyShift 0x03


//
// Platform specific stuff
//

#ifdef HDOS16
#define pbtick ((BYTE FAR *) 0x0040006C)
#define pbshift ((BYTE FAR *) 0x00400017)
#else
#ifdef HDOS32
#define pbtick ((BYTE FAR *) 0x0000046C)
#define pbshift ((BYTE FAR *) 0x00000417)
#else
#ifdef HWIN32
#define pbtick _pbtick()
__inline BYTE FAR *_pbtick()
{
    static BYTE b;

    b = (BYTE)(GetTickCount() / 50);
    return &b;
}
#define pbshift _pbshift()
__inline BYTE FAR *_pbshift()
{
    static BYTE b;

#if 0
    b = ((GetKeyState(VK_SCROLL) & 0x01) ? wScrlLock : 0) |
        ((GetKeyState(VK_CAPITAL) & 0x80) ? wCapsLock : 0) |
        ((GetKeyState(VK_CONTROL) & 0x80) ? wCtrl : 0) |
        ((GetKeyState(VK_SHIFT) & 0x80) ? wAnyShift : 0);
#endif

    return &b;
}
#else
#error
#endif // HWIN32
#endif // HDOS32
#endif // HDOS16


//
// 6502 condition codes in P register: NV_BDIZC
//

#define NBIT 0x80
#define VBIT 0x40
#define BBIT 0x10
#define DBIT 0x08
#define IBIT 0x04
#define ZBIT 0x02
#define CBIT 0x01


//
// All 6502 address space variables are FAR

extern BYTE fTrace, fSIO, mdXLXE, cntTick, fDebugger;

extern WORD wFrame, wScan, wLeft;

extern WORD wJoy0X, wJoy0Y, wJoy1X, wJoy1Y;
extern WORD wJoy0XCal, wJoy1XCal, wJoy0YCal, wJoy1YCal;
extern BYTE bJoyBut;

extern WORD FAR ramtop;

extern WORD fStop;
extern WORD wStartScan;
extern WORD fBrakes;

extern WORD fJoy, fSound, fAutoStart;

//
// Atari 800 hardware read registers
//

// GTIA

#define readGTIA 0xD000

#define MXPF    ((&rgbMem[0xD000]))
#define M0PF    rgbMem[0xD000]
#define M1PF    rgbMem[0xD001]
#define M2PF    rgbMem[0xD002]
#define M3PF    rgbMem[0xD003]

#define PXPF    ((&rgbMem[0xD004]))
#define P0PF    rgbMem[0xD004]
#define P1PF    rgbMem[0xD005]
#define P2PF    rgbMem[0xD006]
#define P3PF    rgbMem[0xD007]

#define MXPL    ((&rgbMem[0xD008]))
#define M0PL    rgbMem[0xD008]
#define M1PL    rgbMem[0xD009]
#define M2PL    rgbMem[0xD00A]
#define M3PL    rgbMem[0xD00B]

#define PXPL    ((&rgbMem[0xD00C]))
#define P0PL    rgbMem[0xD00C]
#define P1PL    rgbMem[0xD00D]
#define P2PL    rgbMem[0xD00E]
#define P3PL    rgbMem[0xD00F]

#define TRIG0   rgbMem[0xD010]
#define TRIG1   rgbMem[0xD011]
#define TRIG2   rgbMem[0xD012]
#define TRIG3   rgbMem[0xD013]

#define PAL     rgbMem[0xD014]

#define CONSOL  rgbMem[0xD01F]

// POKEY

#define readPOKEY 0xD200

#define POT0    rgbMem[0xD200]
#define POT1    rgbMem[0xD201]
#define POT2    rgbMem[0xD202]
#define POT3    rgbMem[0xD203]
#define POT4    rgbMem[0xD204]
#define POT5    rgbMem[0xD205]
#define POT6    rgbMem[0xD206]
#define POT7    rgbMem[0xD207]

#define ALLPOT  rgbMem[0xD208]
#define KBCODE  rgbMem[0xD209]
#define RANDOM  rgbMem[0xD20A]

#define IRQST   rgbMem[0xD20E]
#define SKSTAT  rgbMem[0xD20F]

// PIA

#define readPIA 0xD300

#define PORTAea 0xD300
#define PORTA   rgbMem[0xD300]
#define PORTB   rgbMem[0xD301]

#define PACTLea 0xD302
#define PACTL   rgbMem[0xD302]
#define PBCTL   rgbMem[0xD303]

// ANTIC

#define readANTIC 0xD400

#define VCOUNT  rgbMem[0xD40B]
#define PENH    rgbMem[0xD40C]
#define PENV    rgbMem[0xD40D]
#define NMIST   rgbMem[0xD40F]


//
// Atari 800 hardware write registers
//

// GTIA

#define writeGTIA 0xD110

#define HPOSPX  (*(ULONG *)&rgbMem[0xD110])
#define HPOSP0  rgbMem[0xD110]
#define HPOSP1  rgbMem[0xD111]
#define HPOSP2  rgbMem[0xD112]
#define HPOSP3  rgbMem[0xD113]

#define HPOSMX  (*(ULONG *)&rgbMem[0xD114])
#define HPOSM0  rgbMem[0xD114]
#define HPOSM1  rgbMem[0xD115]
#define HPOSM2  rgbMem[0xD116]
#define HPOSM3  rgbMem[0xD117]

#define SIZEPX  (*(ULONG *)&rgbMem[0xD118])
#define SIZEP0  rgbMem[0xD118]
#define SIZEP1  rgbMem[0xD119]
#define SIZEP2  rgbMem[0xD11A]
#define SIZEP3  rgbMem[0xD11B]
#define SIZEM   rgbMem[0xD11C]

#define GRAFPX  (*(ULONG *)&rgbMem[0xD11D])
#define GRAFP0  rgbMem[0xD11D]
#define GRAFP1  rgbMem[0xD11E]
#define GRAFP2  rgbMem[0xD11F]
#define GRAFP3  rgbMem[0xD120]
#define GRAFM   rgbMem[0xD121]

#define COLPMX  (*(ULONG *)&rgbMem[0xD122])
#define COLPM0  rgbMem[0xD122]
#define COLPM1  rgbMem[0xD123]
#define COLPM2  rgbMem[0xD124]
#define COLPM3  rgbMem[0xD125]

#define COLPFX  (*(ULONG *)&rgbMem[0xD126])
#define COLPF0  rgbMem[0xD126]
#define COLPF1  rgbMem[0xD127]
#define COLPF2  rgbMem[0xD128]
#define COLPF3  rgbMem[0xD129]

#define COLBK   rgbMem[0xD12A]
#define PRIOR   rgbMem[0xD12B]
#define VDELAY  rgbMem[0xD12C]
#define GRACTL  rgbMem[0xD12D]
#define HITCLR  rgbMem[0xD12E]
#define wCONSOL rgbMem[0xD12F]

// POKEY

#define writePOKEY 0xD130

#define AUDF1   rgbMem[0xD130]
#define AUDC1   rgbMem[0xD131]
#define AUDF2   rgbMem[0xD132]
#define AUDC2   rgbMem[0xD133]
#define AUDF3   rgbMem[0xD134]
#define AUDC3   rgbMem[0xD135]
#define AUDF4   rgbMem[0xD136]
#define AUDC4   rgbMem[0xD137]
#define AUDCTL  rgbMem[0xD138]

#define STIMER  rgbMem[0xD139]
#define SKRES   rgbMem[0xD13A]
#define POTGO   rgbMem[0xD13B]

#define SEROUT  rgbMem[0xD13D]
#define IRQEN   rgbMem[0xD13E]
#define SKCTLS  rgbMem[0xD13F]

// PIA

#define writePIA 0xD140

#define wPORTAea 0xD140
#define wPORTA  rgbMem[0xD140]
#define wPORTB  rgbMem[0xD141]

#define wPACTLea 0xD142
#define wPACTL  rgbMem[0xD142]
#define wPBCTL  rgbMem[0xD143]

#define wPADDIRea 0xD144
#define wPADDIR rgbMem[0xD144]
#define wPBDDIR rgbMem[0xD145]

#define wPADATAea 0xD146
#define wPADATA rgbMem[0xD146]
#define wPBDATA rgbMem[0xD147]

#define rPADATAea 0xD148
#define rPADATA rgbMem[0xD148]
#define rPBDATA rgbMem[0xD149]

// ANTIC

#define writeANTIC 0xD150

#define DMACTL  rgbMem[0xD150]
#define CHACTL  rgbMem[0xD151]

#define DLPC    (*(WORD FAR *)&rgbMem[0xD152])
#define DLISTL  rgbMem[0xD152]
#define DLISTH  rgbMem[0xD153]

#define HSCROL  rgbMem[0xD154]
#define VSCROL  rgbMem[0xD155]

#define PMBASE  rgbMem[0xD157]

#define CHBASE  rgbMem[0xD159]
#define WSYNC   rgbMem[0xD15A]

#define NMIEN   rgbMem[0xD15E]
#define NMIRES  rgbMem[0xD15F]


//
// Function prototypes
//

void mon(void);

void __cdecl Go6502(void);
void Interrupt(void);
void CheckKey(void);
void ReadJoy(void);
void MyReadJoy(void);

void SaveVideo(void);
void RestoreVideo(void);
void WaitForVRetrace(void);
void UpdatePorts(void);

void InitSIOV(int, char **);
void SIOV(void);
void DiskConfig(void);

extern int fXFCable;
extern unsigned uBaudClock;

void _SIO_Init(void);
void _SIO_Calibrate(void);
int _SIOV(char *qch, int wDev, int wCom, int wStat, int wBytes, int wSector, int wTimeout);

void InitSoundBlaster();
void DoSound(BYTE voice, WORD freq, BYTE dist, BYTE vol);
void UpdatePokey();

#ifdef HWIN32
BOOL ProcessScanLine(BOOL);
#else
void ProcessScanLine(BOOL);
#endif
void ForceRedraw();

void __cdecl SwapMem(BYTE mask, BYTE flags, WORD pc);
void InitBanks(void);
void ReadROMs();

void CchDisAsm(unsigned int *puMem);
void CchShowRegs(void);

extern BYTE FAR rgbMem[];

void NextCart();
void InitCart();
void BankCart(int i);
void ReadCart(char *);

//
// Various ROM data and swap buffers
//

extern char FAR rgbAtariOSB[]; // Atari 400/800 ROMs

extern char FAR rgbXLXEBAS[], FAR rgbXLXED800[];  // XL/XE ROMs
extern char FAR rgbXLXEC000[], FAR rgbXLXE5000[]; // self test ROMs

#if XE
extern char HUGE rgbXEMem[16][16384];
#endif // XE


//
// The 3 hardware modes
//

#define md800 0
#define mdXL  1
#define mdXE  2


//
// Function prototypes of the Atari 800 VM API
//

BOOL __cdecl InstallAtari();
BOOL __cdecl InitAtari();
BOOL __cdecl UninitAtari();
BOOL __cdecl InitAtariDisks();
BOOL __cdecl MountAtariDisk();
BOOL __cdecl UninitAtariDisks();
BOOL __cdecl UnmountAtariDisk();
BOOL __cdecl WarmbootAtari();
BOOL __cdecl ColdbootAtari();
BOOL __cdecl DumpHWAtari(char *pch);
BOOL __cdecl TraceAtari();
BOOL __cdecl ExecuteAtari();
BOOL __cdecl KeyAtari(ULONG l);
BOOL __cdecl DumpRegsAtari(void);
BOOL __cdecl DisasmAtari(char *pch, ADDR *pPC);
BYTE __cdecl PeekBAtari(ADDR addr);
WORD __cdecl PeekWAtari(ADDR addr);
ULONG __cdecl PeekLAtari(ADDR addr);
BOOL __cdecl PokeLAtari(ADDR addr, ULONG l);
BOOL __cdecl PokeWAtari(ADDR addr, WORD w);
BOOL __cdecl PokeBAtari(ADDR addr, BYTE b);


//
// Map C runtime file i/o calls to appropriate 32-bit calls
//

#ifdef HDOS32
// Watcom doesn't like the underscores

#define _open    open
#define _read    read
#define _write   write
#define _lseek   lseek
#define _close   close
#undef  _O_BINARY
#define _O_BINARY O_BINARY
#undef  _O_RDWR
#define _O_RDWR   O_RDWR
#undef  _O_RDONLY
#define _O_RDONLY O_RDONLY
#endif

#ifdef HWIN32
// Map to Win32 counterparts

#define _open    _lopen
#define _read    _lread
#define _write   _lwrite
#define _lseek   _llseek
#define _close   _lclose
#undef  _O_BINARY
#define _O_BINARY 0
#undef  _O_RDWR
#define _O_RDWR   OF_READWRITE
#undef  _O_RDONLY
#define _O_RDONLY OF_READ
#undef  SEEK_END
#define SEEK_END  FILE_END
#undef  SEEK_SET
#define SEEK_SET  FILE_BEGIN
#endif

#pragma intrinsic(inp)
#pragma intrinsic(outp)

