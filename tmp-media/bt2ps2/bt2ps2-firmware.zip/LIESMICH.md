# BT2PS2 Firmware – fertig gebaut

Gebaut 2026-10-08 aus sfambach/esp32-bt2ps2 (Commit 5e14291), ESP-IDF v5.3.0, `sdkconfig` des Repos (FreeRTOS 1000 Hz, BT Classic + BLE). Pins: CLK IO22, DATA IO23, LED IO2, BOOT IO0.

Build-Korrekturen nur lokal (nicht im Repo): Windows-Pfade `..\include\…` → `../include/…`, `serial_mouse.cpp` in `main/CMakeLists.txt` ergänzt.

## Flashen – Variante 1: Browser (am einfachsten)

1. Chrome/Edge öffnen: https://espressif.github.io/esptool-js/
2. **JP1 offen**, kein PS/2-Kabel. Board per USB anschließen (A: USB am D1 mini, B: USB-Seriell-Adapter an J3).
3. Baudrate **115200** wählen (höhere Werte machten Verbindungsprobleme), „Connect“ → Port wählen. Prüfen: „Connected to device: **ESP32**…“ (nicht ESP8266). B: dabei BOOT halten, RESET tippen, BOOT loslassen.
4. Flash Address auf **`0x0`** ändern – voreingestellt ist `0x1000`, damit bootet der ESP nicht –, Datei `bt2ps2-merged-0x0.bin` → „Program“.
5. Danach RESET (oder USB kurz trennen).

## Variante 2: esptool (Kommandozeile)

```
pip install esptool
esptool --chip esp32 -p COM5 -b 115200 write_flash 0x0 bt2ps2-merged-0x0.bin
```

oder einzeln: `0x1000 bootloader.bin  0x9000 partition-table.bin  0x20000 esp32-bt2ps2.bin` (dio, 40 MHz, 2 MB).

## Kontrolle

Seriellen Monitor auf 115200 Baud (z. B. im esptool-js „Console“ oder PuTTY): Startmeldungen, dann BT-Scan. LED an = Normalbetrieb, LED aus = Pairing.

## Lizenz

MIT, siehe `LICENSE.txt` (Humberto Möckel u. a., BT-Teil Guy Turcotte). Original: https://github.com/Hamberthm/esp32-bt2ps2 – im Beitrag als Quelle nennen.
